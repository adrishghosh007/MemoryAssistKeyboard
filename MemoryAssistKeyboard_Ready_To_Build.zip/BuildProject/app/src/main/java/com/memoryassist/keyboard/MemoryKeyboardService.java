package com.memoryassist.keyboard;

import android.inputmethodservice.InputMethodService;
import android.view.View;

public class MemoryKeyboardService extends InputMethodService {
    @Override
    public View onCreateInputView() {
        return new View(this);
    }
}
