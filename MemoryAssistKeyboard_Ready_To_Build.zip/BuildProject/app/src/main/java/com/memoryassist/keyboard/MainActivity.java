package com.memoryassist.keyboard;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView tv = new TextView(this);
        tv.setText("Memory Assist Keyboard\n\nSetup:\n1. Enable in Settings\n2. Select as Default\n3. Grant Usage Access\n\nAll text typed is encrypted locally.");
        tv.setPadding(20, 20, 20, 20);
        setContentView(tv);
    }
}
